package com.photography.shutterup;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ShutterUpApplication {

    public static void main(String[] args) {
        SpringApplication.run(ShutterUpApplication.class, args);
    }

}
