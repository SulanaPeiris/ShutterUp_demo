package com.photography.shutterup.repository;

import com.photography.shutterup.model.Tutorial;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface TutorialRepository extends JpaRepository<Tutorial, Long> {
    List<Tutorial> findByCategory(String category);
    List<Tutorial> findByUserId(Long userId);
}
