package com.photography.shutterup.dto;

import lombok.Builder;
import lombok.Data;

@Data
@Builder // ✅ This enables StepDTO.builder()
public class StepDTO {
    private String title;
    private String description;
    private String imageUrl;
    private int stepOrder;
}
