package com.photography.shutterup.config;

public class OAuth2Config {
}
